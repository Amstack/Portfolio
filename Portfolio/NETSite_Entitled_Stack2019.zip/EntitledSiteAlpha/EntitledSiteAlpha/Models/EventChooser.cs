﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EntitledSiteAlpha.Models
{
    public class EventChooser
    {
        public int Onyxia { get; set; }
        public int MoltenCore { get; set; }
        public int BWL { get; set; }
        public int AQ { get; set; }
        public int Naxx { get; set; }
        public int PVP { get; set; } 
    }
}
